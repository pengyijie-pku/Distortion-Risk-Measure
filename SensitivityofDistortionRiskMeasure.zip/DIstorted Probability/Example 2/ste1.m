function [X,G,I,I1,F]=ste1(n,s0,r,sigma,delta,lambda,v,k,h,num)
X=normrnd(0,1,num,n);
Y=zeros(num,1);
I=ones(num,1);
F=zeros(num,1);
J=zeros(num,1);
 N=poissrnd(delta*lambda,num,n);
 E=v*normrnd(0,1,num,n);
for i=1:n
 Y=Y+X(:,i);
 J=J+N(:,i).*E(:,i);
G=log(s0)+i*(r-sigma^2/2)*delta+sigma*(delta)^(1/2)*Y+J;
if i<n
I1=(G<log(h));
F=F+I.*(1-I1).*X(:,1)/sigma/s0/(delta)^(1/2);
I=I.*I1;
else
I1=(log(k)<G).*(G<log(h));
end
end
end