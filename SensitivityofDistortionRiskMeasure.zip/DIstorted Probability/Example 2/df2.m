function w=df2(x)
x=1-x;
a=0.9;
w=1*(x>1-a);
end