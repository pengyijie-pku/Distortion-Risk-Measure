function D=sadrm(n,s0,r,sigma,lambda,v,T,k,h,d,num)
%tic
D=0;
delta=T/n;
[X,G,Ind,Ind1,F]=ste1(n,s0,r,sigma,delta,lambda,v,k,h,num);
Y=Ind.*Ind1.*(exp(G)-k);
q=sort(Y);
p1=mean((Y==0));
p2=1;
it=fix((p2-p1)/d);
%E=zeros(1,it);
x=p1+d*((1:it+1)-1);
I=fix(x(2:end)*num);
q=q(I);
w=df2(x);
%w=df3(x,0);
for i=1:it
E=ste2(q(i),n,s0,sigma,delta,k,h,X,G,Ind,F);
D=D+E*(w(i+1)-w(i));
end
%toc
end