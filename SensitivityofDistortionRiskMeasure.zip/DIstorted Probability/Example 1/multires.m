function D=multires
tic
it=100;
D=zeros(1,it);
d=10^(-2);
y=10;
num=10^5;
a=0;
b=inf;
%p=0.01;
for i=1:it
%D(i)=fdc2(d,y,a,b,num,p);
%D(i)=fd(d,y,a,b,num,p);
%D(i)=ipa(d,y,a,b,num);
D(i)=sadrm(d,y,num,a,b);
%D(i)=test3(d,y,a,b,num);
%D(i)=test4(d,y,a,b,num,p);
end
%save('glrm1_2_1','D','d','y','a','b','num')
toc
end