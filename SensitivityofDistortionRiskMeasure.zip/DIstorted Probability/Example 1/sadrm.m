function D=sadrm(d,y,num,a,b)
%tic
D=0;
X1=normrnd(0,1,1,num);
X2=y*normrnd(0,1,1,num);
Y=exp(X1+X2);
q=sort(Y);
p1=mean((Y<a));
p2=mean((Y<b));
it=fix((p2-p1)/d);
%E=zeros(1,it);
x=p1+d*((1:it+1)-1);
I=fix(x(2:end)*num);
q=q(I);
%w=df2(x);
%w=df3(x,0);
w=df4(x,0);
for i=1:it
E=ste(q(i),X1,X2,Y);
D=D+E*(w(i+1)-w(i));
end
%toc
end