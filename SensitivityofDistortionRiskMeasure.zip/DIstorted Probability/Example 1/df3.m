function w=df3(x,o)
x=1-x;
a=0.5;
if o==0
w=min(x/(1-a),1);
else
w=(x<1-a)/(1-a);
end
end